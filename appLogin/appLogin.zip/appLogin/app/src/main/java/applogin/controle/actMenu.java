package applogin.controle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class actMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_menu);
    }
}