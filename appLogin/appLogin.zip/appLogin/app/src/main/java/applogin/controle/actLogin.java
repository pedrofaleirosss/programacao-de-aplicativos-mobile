package applogin.controle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class actLogin extends AppCompatActivity {

    EditText edtLogin, edtSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_login);
        edtLogin = findViewById(R.id.edtLogin);
        edtSenha = findViewById(R.id.edtSenha);
    }
    public void Enviar(View v){
        String login, senha;
        login = edtLogin.getText().toString();
        senha = edtSenha.getText().toString();

        if(login.equals("Pedrolu") && senha.equals("carlos")){

        }
    }
}